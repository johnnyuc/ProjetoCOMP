class Main {
    public static void main(String[] args) {
        int i;
        i = 3;
        double j;
        j = 4;
        j = i + j;
        j = i / j;
        System.out.print(j);
		System.out.print("\n");
    }
}