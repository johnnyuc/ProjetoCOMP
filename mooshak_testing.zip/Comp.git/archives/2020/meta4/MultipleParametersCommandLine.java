class Main {
	//Insert '1' and '2' as params
    public static void main(String[] args) {
        int arg1; 
        arg1 = Integer.parseInt(args[0]);
        int arg2;
        arg2 = Integer.parseInt(args[1]);

        System.out.print(arg1);
        System.out.print("\n");
        System.out.print(arg2);
		System.out.print("\n");
    }
}