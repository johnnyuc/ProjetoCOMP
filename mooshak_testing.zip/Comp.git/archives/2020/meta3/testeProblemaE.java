class Java {
  	public static void funcao2(String[] args){
  		Integer.parseInt(args[0]);
  		boolean a,b;
  		int c,d;
  		a = true;
  		b = true;
  		c = 1;
  		d = 1;
  		if(a+true == 2){
  			System.out.print("olaaaa\n");
  		}
  		a= args.length;
  	} 
  	public static double x(double x, int a){

  	}
    public static void main(String[] args) {
        int x;
        int b;
        x = 1<<(x*1);
    }
   	
   	public static void main(String[] args) {
		int x;
		a = x;
	}

	public static boolean a;
    public static int funcao3(int a,int b,double c){
  	}
  	public static int funcao3(int a,int b,double c){
  	}
  	public static int funcao3(int a,int b,double c){
  	}
  	public static boolean funcao3(int a,int b,boolean c){
  		int x;
  		int y;
  		int z;
  		int w;
  	}
    public static boolean funcao;
	public static int funcao(int i, double i){
  	}
    public static void funcao(double i, int funcao){
        boolean m;
        
    }
    public static double funcao(double i, double funcao){
        int m;
        if(m == 1){
            funcao(m,m);
        }
    }
  	public static int funcao(int i, int i){ 
  	}
    public static double funcao;
    public static void maine(){
        int a,b,c,d;
        double e,f,g,h;
        boolean i,j,k,l;
        k= 1+1+(e)/4*-4.3%10;
        a= 1+1+(e)/4*-4.3%10;
        b= 1+1+(e)/4*-4.3%10;
        i = !!!!!!!l;
        f = Integer.parseInt(i[1+1.0+2]);
    }
    public static int ola56(int x1) {
        x1 = ola56;
        System.out.print("");
    }
    public static boolean ola56;
}

