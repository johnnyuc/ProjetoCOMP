class Sum {
    public static void operator(){

    }

    public static void main() {
        int a,b,c;
        double d,e;
        boolean x,y;

        if(x==y){
        	if(a==b){
        		if(d==b){
        			x = ((d*e)<=(a>>c))||((x)==(!y));
        		}
        	}
        }

        operator();
    }

}