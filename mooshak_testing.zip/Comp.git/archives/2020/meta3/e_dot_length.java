class ClassTeste {

    public static void main(String[] args) {
        boolean b;
        int i;
        double d;

        i = i.length;
        i = b.length;
        i = d.length;
        i = args.length; // Correto
        i = undef.length;

        b = i.length;
    }
}