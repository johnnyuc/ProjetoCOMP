class Java {
  public static int a(){
    int a;
    a = b + true;
    a = b + 1.0_43443;
    a = b + 1;
    a = b + c;
    int b,c;
    a = b + c;
  }
}
