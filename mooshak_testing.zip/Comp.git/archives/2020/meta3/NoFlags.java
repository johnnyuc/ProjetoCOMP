//Test using no flags!!! (./jucompiler < NoFlags.java)
class NoFlags {
	public static int a(int n) {
        	int a;
			a = 2147483648;
        }

	public static int a(double n) {
        	int b;
			b = 21474_8_3647;
        }

	public static int a(boolean n, int a, boolean c) {
        	int d;
			d = 2147483649;
			d = c;
        }

	public static int a(int n) {
        	int d;
			d = 10_0000_00000;
        }

    public static void main(String[] args) {
        Integer.parseInt(s[2.2]);
        System.out.print(2e2);
    }
}