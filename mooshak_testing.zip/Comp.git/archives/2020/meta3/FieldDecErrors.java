class ClassTeste {

    public static int teste0 , teste1, teste2;

    public static int teste2;


    public static void main(String[] args) {
        int argument;
        argument = Integer.parseInt(args[0]);
        System.out.print(factorial(argument));
    }
}