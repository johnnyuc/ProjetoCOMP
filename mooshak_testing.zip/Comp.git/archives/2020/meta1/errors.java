// jucompiler -e1 < errors.java
// the standard Java compiler also shows these lexical errors

class Small #
	public static void main(String[] args) {
	}
#
