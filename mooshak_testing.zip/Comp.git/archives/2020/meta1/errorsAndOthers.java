recurso &
recurso"as\5recurso\x
"recurso\g"
"123\g456"
"123\g456
"\
0123.3
3.333_e_1
recurso"\
"\"recurso
#"\"
#linha#
`'

"outraLinha"
#"recurso''"?//
xD ?\n|''
int a =x?00123321
ttrhwrhewrjree//adsasd?????????
	?		?
	"asdadasdas"
"dsadasd sadsad"
"dasdsadas		asdasd123"
"dsadasdas\n"
sd"umalinha
duaslinhas
ultimalinha"
""
"\tadssadsadsa\t"
"\\"
"\f"
"\r\f"
"aspas\""
"\\dsadasdsadas"
\"\b