boolean
// one line comment
double
/* 	multi
	line
	comment
*/
&&
/* 123 !?== static*/