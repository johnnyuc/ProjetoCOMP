class program{
	public static void main(){
		if(x==1){}
		if(x==1){}else{}
		if(x==1){statement();}
		if(x==1){statement1();statement2();}
		if(x==1){statement3();statement4();}else{statement5();statement6();}
	}
}