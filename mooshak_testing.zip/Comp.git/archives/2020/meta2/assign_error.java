class assign_error {
  public static void main(String[] args) {
    f(i = j = a&&b = l);
  }
}

