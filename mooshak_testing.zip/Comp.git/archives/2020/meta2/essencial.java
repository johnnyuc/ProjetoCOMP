// teste com o minimo possivel apenas para dar pritn de program, methodParams e methodBody
class Teste{
    // tem que dar void, id main e depois methodParams sem filhos
    public static void main (){
        // aqui apesar de tar vazio tem que dar methodbody
    }
}