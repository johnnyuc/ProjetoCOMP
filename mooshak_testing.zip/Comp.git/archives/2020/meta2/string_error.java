
// Neste caso de teste facam com a flag -e2

class Teste {
  public static int main(String[] args){
    int ru; int vv;
      if(false)
        "strlit"
      else
        return;
  }
}
