//flag -e2

class Factorial {
    public static boolean b, a, c;
    public static boolean a(){
        int x, d;
        int a,
    };
    public static int factorial(int n) {
    }
}