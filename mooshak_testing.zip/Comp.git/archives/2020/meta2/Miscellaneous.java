
class Teste {
  public static int main(String[] args){
    if (Miguel+Paulo==juntos_nos_projetos_todos) {
      System.out.print("20 no projeto de SD");
      System.out.print("20 no projeto de PPP");
      System.out.print("20 no projeto de POO");
      System.out.print("20 no projeto de TI");
      System.out.print("20 no projeto de MULTIMEDIA");
      System.out.print("20 no projeto de IRC");
        if (cadeira==SCC) {
          if(0){if(0){if(0){if(0){if(0){if(0){if(0){if(0){if(0){
            System.out.print("Plagio mas depois 15");
          }}}}}}}}}

        }
    }
    soQuero800NestaMeta((((1__3))),miguel,soQuero800NestaMeta(1+1));
    System.out.print(Paulo = Gostoso);
    while((caso_da_zara_de_SI(caso_da_zara_de_SI(caso_da_zara_de_SI())))){
      vontade_de_morrer = vontade_de_morrer*1_000_000.0__0__0;
    }
    paulo = Integer.parseInt(paulo[Integer.parseInt(paulo[Integer.parseInt(paulo[Integer.parseInt(paulo[Integer.parseInt(paulo[0])])])])]);

    return carry = Integer.parseInt(miguel[!ola+5*5-5/5<5>5||5&&5==5%5+(((carry+123332_445e+2__442)))]);
    if (((((((0)))))))
      return 1;
    else
      return 0;

    if (a){
      {{return;}}
      {{{{{{{{{{{{{{{{return;}}}}}}}}}}}}}}}}
    }
  }
}
