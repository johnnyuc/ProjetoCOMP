// Se compilarem com a flag -e2, da erro do unterminated string literal
// Se compilarem com a flag -t, da o erro na mesma, mas a AST e impressa
// 

class errorsAndAST {
  public static void main(String[] args) {
    //a = "nao desistam amigos";
    "sdfsdfsdf
    if(A)
        if(0) System.out.print(0);
          else
            if(x) {
                if (1);
            } else
                if(ABC) {
                    {;}
                } else x=1;

    while (tiago_to == manolos_simpaticos){
        System.out.print("Impossivel sair daqui eheh");
    }
    
    while(a){
        while (b){
            while (espero){
                while (isto){
                    while (funcione){
                        while (bem){
                            System.out.print("RUMO AOS 800!!");
                        }
                    }
                }
            }
        }
    }


    if(tiago_to);     else ;

    if (true)
        if (true)
            if (false)
                {}
            else
                {}
        else
            if (ABC)
                {}
            else
                {}
    if (false) {} else if (false) {}
  }
}
