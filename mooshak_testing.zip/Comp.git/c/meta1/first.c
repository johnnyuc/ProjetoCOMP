int main(void) {
  char i = 'A';
  while (i <= 'Z') {
    putchar(i);
    i = i + 1;
  }
  return 0;
}
