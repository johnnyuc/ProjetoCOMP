//teste comentario
/* este está certo
nao
deve dar
erro
aqui
*/
/*  						*/   
/* teste de
erro
de
comentario

