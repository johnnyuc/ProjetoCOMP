int main(void){
    int # = 223;
    int var = 0;
    if(var<1){ /*
 */ #   return 0;
    }else{
        return 1;
    }
}
