'asdasdasdasdasdasdasd'
'\0'
'\0000'
'\00 0'
'\002'
' \0'
'\0'
'
' '
'\n'
'\t'
'\\'
'\\'
'\''
'\h'
/* asdasd
asdasd */
'\"''a''\\''\'' 'asdasd' '\n\n' '\r'
'\\'
'\t'
'\"'
' \t'
'\t\n'
'\' asasd '
'\''
'asd'
'\'  asdasd'
'\123'
'\t'
'\"'
'\" asd'
'\n asd'
'\n asd'' ''\t\n'
'
'asdasd'
'/'
'\123jasdjasdjasdja\' asdasd \''
'\123'
'\00' 
'\\'  ' \' '
'
asd
'
'\\'
'\n'
'\t''\n''\tt'
'\''
'\"'
'\1'
'\11'
'FOFA:SE'
'\111'
'\a'
'\\'  sdasd  '\' asdasdasd ''
\'
'\t'
'\n\m'
'\m'111
'asdasd'
'#'
'\0000'
'\'
asd
'\ asdjasd asdajsda asd '
'\\\'asdasd\ '
'\777'
'\n'
'\7\234'
'\7\"'
'\''
'\"'
'4'
'\''asddasd''\''''''
'''asdasd \'
'''\'\0n'
'asdasdasdasd' '\\'?'\nnnn''!'
'\asjdasd\'0'\n
'()'
'('
'\"'
'  \t	)'
'	'
'	'
'\\''\n'
'asjdajsd'
'a'
'A'
'!'
'\nasd'
'asdasd ' 'aasdasd'
'







'
'\n'
'\asdasd asd asd \ ' '\\\\\\\'' '"asdasd\"' 
'	' 'asd'
'asdasd asd asd as dasd as da sd asd as da sda sda sd asd asd as da sdas dasd'
'\'
asdasd
asd
asd
'\001'
'/*\''
'\n\asdasd'
'\n\n'
'		'
0
'asdasd
asda
asd
asd
a
sd
asd'\'''''\''''''''''''''''''''''''''
'asdasda'
'\asdjasd'
'\='
'g'
'123123123123'''
'\''\\'
\'
'\\\\'
'\ asdasd
'\\
'asdasd \
