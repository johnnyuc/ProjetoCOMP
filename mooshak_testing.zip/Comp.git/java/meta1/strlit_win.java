"isto é uma frase
	"isto é outra frase \
"\n\g\r"
