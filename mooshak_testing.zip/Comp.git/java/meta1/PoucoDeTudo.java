class Compiladores2020/2019
/* Nao esta nada facil fazer comp

	O valor do pi 3.14 nao e igual
	a 34.34E-3*/* */

while e-1++
System.out.print(" Nao deu em nada \
" \\ ")
" no token .length \n \f \	
//IMPORTANTE \n é suposto ser ignorado
0.0e0.0e0.0
123.123e123e--123 -> reallit? " \\\\\n 	"