02115
1215
125_251
0_1515_0
001_15151_2

12.12
E+2
0.124
24_.52
024.E
24_E
02.14
0.02
.01
.999
423e-3
0E+4
05e2
09.5e+1
0.4e2
64.8E-2
64.E
.
e-1
e2
.e2

"string"
"varios escapes \n \f \r"
"nao acabei
"\
"newline"
"\"\""
""""
"\n"
"
"carriage return

""aaaaa
"	a
"   " "nao acabo e dou erro \h
"eof