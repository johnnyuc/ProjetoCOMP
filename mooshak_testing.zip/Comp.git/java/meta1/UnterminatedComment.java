// terminated 
/* comment does not end
* 
// what